package app;

import java.util.Comparator;


public class InsertionSorter<T> extends AbstractSorter<T> {

	public InsertionSorter(SwapList<T> list, Comparator<T> comparator) {
		super(list, comparator);
	}

	@Override
	public SwapList<T> sort() {
		// TODO sort
		int j;
		for (int i = 1; i < list.size(); ++i) {
		j = i;
	// Insert numbers[i] into sorted part
	// stopping once numbers[i] in correct position
		while (j > 0 && list.compare(j, j-1, comparator)< 0) {
		
	   // Swap numbers[j] and numbers[j - 1]
	   list.swap(j, j-1);
	   j--;
	}
	}
	return list;
	}
}
