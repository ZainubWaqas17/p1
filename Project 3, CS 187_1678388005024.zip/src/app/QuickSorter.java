package app;

import java.util.Comparator;


public class QuickSorter<T> extends AbstractSorter<T> {

	public QuickSorter(SwapList<T> list, Comparator<T> comparator) {
		super(list, comparator);
	}

	@Override
	public SwapList<T> sort() {
		// TODO sort
		//InsertionSorter<T> obj = new InsertionSorter<T>(list, comparator);
		//if(list.scoreList(comparator) > 50){
		//obj.sort();
		//}else{
			quickSort(list, 0, list.size()-1);
			//}
			return list;
		}
	
	
	
		public void quickSort(SwapList<T> list,int lowIndex,int highIndex) {
			 
			while (lowIndex < highIndex)
		{
			int pivot = partition(list, lowIndex, highIndex);
	 
			// recur on the smaller subarray
			if (pivot - highIndex < lowIndex - pivot)
			{
				quickSort(list, highIndex, pivot - 1);
				lowIndex = pivot + 1;
			}
			else
			{
				quickSort(list, pivot + 1, highIndex);
				highIndex = pivot - 1;
			}
		}
	}
	
	
	
	
	
	
		   /* if (lowIndex >= highIndex) {
			   return;
			}
		   
		 
			int lowEndIndex = partition(list, lowIndex, highIndex);
			quickSort(list, lowIndex, lowEndIndex);
			quickSort(list, lowEndIndex + 1, highIndex);
		 }*/
	
	
		 public  int partition(SwapList<T> list, int lowIndex, int highIndex){
			boolean done = false;// val to break out of loop. when i and j overlap or pass each other
		   
		   
			int midpoint = lowIndex + (highIndex-lowIndex)/2; // find midpoint, pivot can be anything in this case it is midpoint, plus low index to account for start not always 0
			
			while (!done){
	
			   while(list.compare(lowIndex, midpoint, comparator) < 0){
				 lowIndex++;
			  }
	  
			   while (list.compare(highIndex, midpoint, comparator) > 0){
				 highIndex--;
			  }
			   
			  if (lowIndex >= highIndex){
				  done = true;
				  }else{
				   list.swap(lowIndex, highIndex);
				   lowIndex ++;
				   highIndex --;
				  }
			}
	  
		  return highIndex;// highest index of low partition
	  }
}
